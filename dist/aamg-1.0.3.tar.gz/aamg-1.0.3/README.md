![logo](https://private-user-images.githubusercontent.com/143928932/407652250-ce9a1b5b-4c86-40dc-bb95-48ba4ae895f3.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3MzgxMzg4MDUsIm5iZiI6MTczODEzODUwNSwicGF0aCI6Ii8xNDM5Mjg5MzIvNDA3NjUyMjUwLWNlOWExYjViLTRjODYtNDBkYy1iYjk1LTQ4YmE0YWU4OTVmMy5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjUwMTI5JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI1MDEyOVQwODE1MDVaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT0wODI1NjZhZGEwMjQ4YTM5MWNjMGRjOTE2ZTg4NzIxZDI1MzczYTU2MjQ2NmY2OTQyOGU4OTcxMmVjNjhmMmVhJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.IZJDvgGauzCFZ5GAqT8sxElcJUypyxSqm0amfLJjoM4)

**THE Advanced Application Manager Generator**  or **AAMG** is a Python library for creating **AAMs** from A to Z using Python.

**NOTE: THE AAMG and any AAM CAN ONLY work in any windows operating system(\*1) which can support python 3.8 and above**

**\*1: THE AAMG and any kind of AAM wasn't test on an 32-bit operating system but only 64-bit operating system only**

**AAMG** produces **custom AAMs** by using a Variety of Parameters which enable it
to produce AAMs for **any application or purpose**.

Advanced Application Manager or AAM is a very flexable and useful way to install dependencies and requirements for a specific app,
each AAM is made specifically for a specific application, and the only way to make an AMM is to use the AAMG python library
which is has been **made using pure python and standard libraries only**

## Install

to install use the following command

<code>pip install aamg</code>

## Contribute

if you have discovered a bug, or you want to change something just open a new issue
at [Issues](https://github.com/WeDu-official/AAMG/issues)

## Contact

you can contact us using this [email](mailto:fplu.the.founder@gmail.com)
,and you can be a part of our community by joining [our discord server](https://discord.gg/mnduzx6yUg)